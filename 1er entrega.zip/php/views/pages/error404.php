<div class="error_404">
    <img src="../img/404.jpg">
</div>
