<?php

class ControladorPlantilla{
    public function ctrGetPlantilla(){
        include './php/views/plantilla.php';
    }
}


