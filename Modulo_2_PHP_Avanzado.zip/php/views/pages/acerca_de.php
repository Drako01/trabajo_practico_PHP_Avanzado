
<section class="acerca" id="acerca">
    <div class="acerca_de">

        <p>
            Desde el corazón de Nuñez los llevamos por un viaje gastronómico a la ciudad de Nápoles degustando de nuestras pizzas estilo napoletano siguiendo las recetas tradicionales con la más alta calidad de productos importados e ingredientes italianos.

            La comida, los tragos y los vinos que ofrecemos se disfrutan entre amigos, familia o una cita íntima con tu pareja en nuestro ambiente cálido del salón o en nuestro hermoso patio al aire libre.
        </p>

    </div>

</section>