<div class="error_404">
    <div class="titulo">
        <a href="index.php?ruta=login"><button class="boton"> Volver </button></a>
    </div>
    <img src="img/404.png">
</div>
<style>
    footer {
        display: none;
    }
</style>