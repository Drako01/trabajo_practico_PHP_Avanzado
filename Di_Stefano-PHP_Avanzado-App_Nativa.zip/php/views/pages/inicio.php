

<div class="body_bg01"></div>

<div class="logo">
    <img src="img/logo.png">
</div>

<div class="body_bg02"></div>